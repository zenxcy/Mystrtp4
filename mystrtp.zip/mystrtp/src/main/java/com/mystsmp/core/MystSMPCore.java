package com.mystsmp.core;

import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class MystSMPCore extends JavaPlugin implements Listener {

    private Msg msg;
    private SafeLocator locator;
    private RtpService rtp;
    private QueueManager queues;
    private Dialogs dialogs;

    private EconomyHook economy;
    private OrderManager orders;
    private DeliveryService delivery;
    private OrderDialogs orderDialogs;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        upgradeConfig();

        this.msg = new Msg(this);
        this.locator = new SafeLocator(this);
        this.rtp = new RtpService(this, msg, locator);
        this.queues = new QueueManager(this, msg, locator);
        this.dialogs = new Dialogs(this, queues, rtp);

        this.economy = new EconomyHook();
        this.orders = new OrderManager(this);
        this.delivery = new DeliveryService(this, msg, orders, economy);
        this.orderDialogs = new OrderDialogs(this, msg, orders, economy, delivery);

        Commands commands = new Commands(this, msg, rtp, queues, dialogs, orderDialogs);
        for (String name : new String[]{"rtp", "rtpq", "rtpqleave", "order", "mystsmp"}) {
            PluginCommand cmd = getCommand(name);
            if (cmd != null) {
                cmd.setExecutor(commands);
                cmd.setTabCompleter(commands);
            }
        }

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(delivery, this);

        if (!economy.available()) {
            getLogger().warning("Walang Vault economy na nahanap (baka mamaya pa mag-load). "
                    + "Kailangan ito ng /order. Siguraduhing may Vault at economy plugin.");
        }
        getLogger().info("MystSMPCORE enabled.");
    }

    /** Kapag luma ang config.yml, i-backup (config-old.yml) at gumawa ng bago para makuha ang bagong settings. */
    private void upgradeConfig() {
        if (getConfig().getInt("config-version", 0) >= 3) {
            return;
        }
        java.io.File current = new java.io.File(getDataFolder(), "config.yml");
        java.io.File backup = new java.io.File(getDataFolder(), "config-old.yml");
        if (backup.exists()) {
            backup.delete();
        }
        if (current.renameTo(backup)) {
            getLogger().info("Luma ang config.yml, ginawang config-old.yml at gumawa ng bago.");
        }
        saveDefaultConfig();
        reloadConfig();
    }

    @Override
    public void onDisable() {
        if (queues != null) {
            queues.clear();
        }
        if (delivery != null) {
            delivery.closeAll();
        }
        if (orders != null) {
            orders.flushPayouts();
            orders.save();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        queues.leaveSilently(event.getPlayer().getUniqueId());
    }
}
