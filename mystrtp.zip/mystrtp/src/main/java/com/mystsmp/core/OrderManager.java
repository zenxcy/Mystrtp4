package com.mystsmp.core;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Taga-imbak ng lahat ng orders (orders.yml). */
public final class OrderManager {

    private final MystSMPCore plugin;
    private final File file;
    private final Map<Integer, Order> orders = new LinkedHashMap<>();
    private int nextId = 1;

    /** Bayad na naghihintay sa delivery delay. Ibabayad lahat kapag nag-shutdown. */
    private final List<Runnable> pendingPayouts = new ArrayList<>();

    public OrderManager(MystSMPCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "orders.yml");
        load();
    }

    // ------------------------------------------------------------------ data

    private void load() {
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        nextId = Math.max(1, yml.getInt("next-id", 1));
        ConfigurationSection section = yml.getConfigurationSection("orders");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(key);
            if (s == null) {
                continue;
            }
            try {
                Material material = Material.matchMaterial(s.getString("material", ""));
                if (material == null) {
                    continue;
                }
                Order o = new Order(
                        Integer.parseInt(key),
                        UUID.fromString(s.getString("owner", "")),
                        s.getString("owner-name", "?"),
                        material,
                        s.getLong("requested"),
                        s.getDouble("price"),
                        s.getLong("created"),
                        s.getLong("delivered"),
                        s.getLong("collected"));
                orders.put(o.id, o);
                nextId = Math.max(nextId, o.id + 1);
            } catch (Exception e) {
                plugin.getLogger().warning("Hindi ma-load ang order " + key + ": " + e.getMessage());
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("next-id", nextId);
        for (Order o : orders.values()) {
            String base = "orders." + o.id + ".";
            yml.set(base + "owner", o.owner.toString());
            yml.set(base + "owner-name", o.ownerName);
            yml.set(base + "material", o.material.name());
            yml.set(base + "requested", o.requested);
            yml.set(base + "price", o.price);
            yml.set(base + "created", o.created);
            yml.set(base + "delivered", o.delivered);
            yml.set(base + "collected", o.collected);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Hindi ma-save ang orders.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ queries

    public Order find(int id) {
        return orders.get(id);
    }

    /** Mga order na may natitira pang i-deliver, pinakamataas na presyo muna. */
    public List<Order> active(String filter) {
        String f = filter == null ? "" : filter.toLowerCase(Locale.ROOT).trim().replace(' ', '_');
        List<Order> out = new ArrayList<>();
        for (Order o : orders.values()) {
            if (o.remaining() > 0 && (f.isEmpty() || o.material.name().toLowerCase(Locale.ROOT).contains(f))) {
                out.add(o);
            }
        }
        out.sort((a, b) -> {
            int c = Double.compare(b.price, a.price);
            return c != 0 ? c : Integer.compare(a.id, b.id);
        });
        return out;
    }

    public List<Order> ownedBy(UUID owner) {
        List<Order> out = new ArrayList<>();
        for (Order o : orders.values()) {
            if (o.owner.equals(owner)) {
                out.add(o);
            }
        }
        return out;
    }

    public int activeCount(UUID owner) {
        int n = 0;
        for (Order o : orders.values()) {
            if (o.owner.equals(owner) && o.remaining() > 0) {
                n++;
            }
        }
        return n;
    }

    // ------------------------------------------------------------------ changes

    public Order create(UUID owner, String ownerName, Material material, long amount, double price) {
        Order o = new Order(nextId++, owner, ownerName, material, amount, price,
                System.currentTimeMillis(), 0, 0);
        orders.put(o.id, o);
        save();
        return o;
    }

    public void remove(Order order) {
        orders.remove(order.id);
        save();
    }

    /** Alisin ang order kapag tapos na lahat. */
    public void cleanup(Order order) {
        if (order.finished()) {
            remove(order);
        } else {
            save();
        }
    }

    // ------------------------------------------------------------------ payouts

    public void addPending(Runnable payout) {
        pendingPayouts.add(payout);
    }

    public void removePending(Runnable payout) {
        pendingPayouts.remove(payout);
    }

    /** Ibayad agad lahat ng naghihintay (shutdown). */
    public void flushPayouts() {
        for (Runnable r : new ArrayList<>(pendingPayouts)) {
            r.run();
        }
        pendingPayouts.clear();
    }
}
