package com.mystsmp.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Countdown (title sa gitna ng screen) bago mag-teleport. */
final class Countdown {

    private Countdown() {
    }

    static void run(MystSMPCore plugin, Msg msg, Collection<Player> players, int seconds,
                    boolean cancelOnMove, Runnable onDone, Runnable onCancel) {
        if (seconds <= 0) {
            onDone.run();
            return;
        }

        List<Player> list = List.copyOf(players);
        Map<UUID, Location> starts = new HashMap<>();
        for (Player p : list) {
            starts.put(p.getUniqueId(), p.getLocation().clone());
        }

        Title.Times times = Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO);
        Component subtitle = msg.raw("countdown-subtitle");

        new BukkitRunnable() {
            int left = seconds;

            @Override
            public void run() {
                for (Player p : list) {
                    if (!p.isOnline()) {
                        stop(null);
                        return;
                    }
                    if (cancelOnMove && moved(starts.get(p.getUniqueId()), p.getLocation())) {
                        stop(p);
                        return;
                    }
                }

                if (left <= 0) {
                    cancel();
                    for (Player p : list) {
                        p.clearTitle();
                    }
                    onDone.run();
                    return;
                }

                Title title = Title.title(
                        Component.text(String.valueOf(left), NamedTextColor.WHITE, TextDecoration.BOLD),
                        subtitle, times);
                for (Player p : list) {
                    p.showTitle(title);
                    p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.0f);
                }
                left--;
            }

            private void stop(Player mover) {
                cancel();
                for (Player p : list) {
                    if (p.isOnline()) {
                        p.clearTitle();
                    }
                }
                if (mover != null) {
                    msg.send(mover, "countdown-cancelled");
                }
                onCancel.run();
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private static boolean moved(Location start, Location now) {
        if (start == null || start.getWorld() != now.getWorld()) {
            return true;
        }
        return start.getBlockX() != now.getBlockX() || start.getBlockZ() != now.getBlockZ();
    }
}
