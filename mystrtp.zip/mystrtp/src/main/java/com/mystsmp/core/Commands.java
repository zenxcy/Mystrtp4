package com.mystsmp.core;

import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public final class Commands implements TabExecutor {

    private static final List<String> WORLDS = List.of("overworld", "nether", "end");

    private final MystSMPCore plugin;
    private final Msg msg;
    private final RtpService rtp;
    private final QueueManager queues;
    private final Dialogs dialogs;
    private final OrderDialogs orderDialogs;

    public Commands(MystSMPCore plugin, Msg msg, RtpService rtp, QueueManager queues, Dialogs dialogs,
                    OrderDialogs orderDialogs) {
        this.plugin = plugin;
        this.msg = msg;
        this.rtp = rtp;
        this.queues = queues;
        this.dialogs = dialogs;
        this.orderDialogs = orderDialogs;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        if (name.equals("mystsmp")) {
            if (!sender.hasPermission("mystsmp.admin")) {
                msg.send(sender, "no-permission");
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                plugin.reloadConfig();
                msg.send(sender, "reload");
            } else {
                sender.sendMessage(Msg.parse("<#a855f7>MystSMPCORE <gray>- /mystsmp reload"));
            }
            return true;
        }

        if (!(sender instanceof Player player)) {
            msg.send(sender, "console");
            return true;
        }

        switch (name) {
            case "rtp" -> {
                if (!player.hasPermission("mystsmp.rtp")) {
                    msg.send(player, "no-permission");
                    return true;
                }
                if (args.length == 0) {
                    dialogs.openRtp(player);
                    return true;
                }
                String arg = args[0].toLowerCase(Locale.ROOT);
                if (arg.equals("queue") || arg.equals("q")) {
                    dialogs.openQueue(player);
                    return true;
                }
                World.Environment env = parseEnv(arg);
                if (env == null) {
                    dialogs.openRtp(player);
                } else {
                    rtp.rtp(player, env);
                }
            }
            case "rtpq" -> {
                if (!player.hasPermission("mystsmp.rtpq")) {
                    msg.send(player, "no-permission");
                    return true;
                }
                if (args.length > 0) {
                    World.Environment env = parseEnv(args[0].toLowerCase(Locale.ROOT));
                    if (env != null) {
                        queues.join(player, env);
                        return true;
                    }
                }
                dialogs.openQueue(player);
            }
            case "order" -> {
                if (!player.hasPermission("mystsmp.order")) {
                    msg.send(player, "no-permission");
                    return true;
                }
                orderDialogs.openMenu(player);
            }
            case "rtpqleave" -> {
                if (!player.hasPermission("mystsmp.rtpq")) {
                    msg.send(player, "no-permission");
                    return true;
                }
                queues.leave(player);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (args.length != 1) {
            return List.of();
        }
        String typed = args[0].toLowerCase(Locale.ROOT);
        return switch (name) {
            case "rtp" -> Stream.concat(WORLDS.stream(), Stream.of("queue"))
                    .filter(s -> s.startsWith(typed)).toList();
            case "rtpq" -> WORLDS.stream().filter(s -> s.startsWith(typed)).toList();
            case "mystsmp" -> Stream.of("reload").filter(s -> s.startsWith(typed)).toList();
            default -> List.of();
        };
    }

    private World.Environment parseEnv(String s) {
        return switch (s) {
            case "overworld", "world", "normal" -> World.Environment.NORMAL;
            case "nether" -> World.Environment.NETHER;
            case "end", "the_end" -> World.Environment.THE_END;
            default -> null;
        };
    }
}
