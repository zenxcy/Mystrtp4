package com.mystsmp.core;

import org.bukkit.Material;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Maliliit na helper para sa format at pag-parse ng numero/pangalan. */
final class Fmt {

    private static final DecimalFormat MONEY = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));

    private Fmt() {
    }

    static String money(double amount) {
        return "$" + MONEY.format(amount);
    }

    /** "bone_block" -> "Bone Block" */
    static String name(Material material) {
        String[] parts = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }

    /** Presyo na parang sa screenshot, hal. 500.0 */
    static String price(double price) {
        return Double.toString(price);
    }

    /** Tumatanggap ng 64, 1,000, 5k, 2.5m, 1b. Ibabalik null kung mali. */
    static Double parseNumber(String raw) {
        if (raw == null) {
            return null;
        }
        String s = raw.trim().toLowerCase(Locale.ROOT).replace(",", "").replace("_", "").replace(" ", "");
        if (s.isEmpty()) {
            return null;
        }
        double mult = 1;
        char last = s.charAt(s.length() - 1);
        if (last == 'k') {
            mult = 1_000d;
        } else if (last == 'm') {
            mult = 1_000_000d;
        } else if (last == 'b') {
            mult = 1_000_000_000d;
        }
        if (mult != 1) {
            s = s.substring(0, s.length() - 1);
        }
        try {
            double v = Double.parseDouble(s) * mult;
            if (Double.isNaN(v) || Double.isInfinite(v)) {
                return null;
            }
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** "bone", "Bone Block", "bone_block" -> Material. Item lang ang tinatanggap. */
    static Material parseItem(String raw) {
        if (raw == null) {
            return null;
        }
        String s = raw.trim().toUpperCase(Locale.ROOT).replace(' ', '_');
        if (s.isEmpty()) {
            return null;
        }
        Material m = Material.matchMaterial(s);
        if (m == null || m.isAir() || !m.isItem() || m.name().startsWith("LEGACY_")) {
            return null;
        }
        return m;
    }
}
