package com.mystsmp.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;

public final class Msg {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final MystSMPCore plugin;

    public Msg(MystSMPCore plugin) {
        this.plugin = plugin;
    }

    /** Message na may prefix. */
    public Component get(String key, TagResolver... resolvers) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        return MM.deserialize(prefix + rawString(key), resolvers);
    }

    /** Message na walang prefix. */
    public Component raw(String key, TagResolver... resolvers) {
        return MM.deserialize(rawString(key), resolvers);
    }

    private String rawString(String key) {
        String value = plugin.getConfig().getString("messages." + key);
        return value != null ? value : "<red>Missing message: " + key;
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(get(key, resolvers));
    }

    /** Parse ng kahit anong MiniMessage string (para sa titles/body ng dialog). */
    public static Component parse(String miniMessage) {
        return MM.deserialize(miniMessage);
    }
}
