package com.mystsmp.core;

import org.bukkit.Material;

import java.util.UUID;

/** Isang order: humihiling ang owner ng item, binabayaran niya ang bawat na-deliver. */
final class Order {

    final int id;
    final UUID owner;
    final String ownerName;
    final Material material;
    long requested;          // nagiging katumbas ng delivered kapag na-cancel
    final double price;      // bawat item
    final long created;
    long delivered;          // ilan na ang na-deliver
    long collected;          // ilan na ang kinuha ng owner

    Order(int id, UUID owner, String ownerName, Material material, long requested, double price,
          long created, long delivered, long collected) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName;
        this.material = material;
        this.requested = requested;
        this.price = price;
        this.created = created;
        this.delivered = delivered;
        this.collected = collected;
    }

    long remaining() {
        return requested - delivered;
    }

    long uncollected() {
        return delivered - collected;
    }

    /** Tapos na ang order: kumpleto ang delivery at nakuha na lahat ng owner. */
    boolean finished() {
        return remaining() <= 0 && uncollected() <= 0;
    }
}
