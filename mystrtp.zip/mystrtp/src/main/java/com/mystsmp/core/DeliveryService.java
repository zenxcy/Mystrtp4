package com.mystsmp.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Pag-deliver ng order: bubukas ang malaking chest, ilalagay ng player ang items,
 * at pag-close ng chest ay made-deliver na. May "Delivering..." delay bago ang bayad.
 */
public final class DeliveryService implements Listener {

    /** Holder para makilala ang delivery chest. */
    static final class DeliverHolder implements InventoryHolder {
        final int orderId;
        final long maxAmount;
        Inventory inventory;

        DeliverHolder(int orderId, long maxAmount) {
            this.orderId = orderId;
            this.maxAmount = maxAmount;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final MystSMPCore plugin;
    private final Msg msg;
    private final OrderManager orders;
    private final EconomyHook eco;

    public DeliveryService(MystSMPCore plugin, Msg msg, OrderManager orders, EconomyHook eco) {
        this.plugin = plugin;
        this.msg = msg;
        this.orders = orders;
        this.eco = eco;
    }

    /** Buksan ang malaking chest (54 slots) para ilagay ang items. */
    public void openChest(Player player, Order order, long amount) {
        DeliverHolder holder = new DeliverHolder(order.id, amount);
        Inventory inv = Bukkit.createInventory(holder, 54,
                Component.text("Deliver " + Fmt.name(order.material), NamedTextColor.WHITE));
        holder.inventory = inv;
        player.openInventory(inv);
        msg.send(player, "order-put-items",
                Placeholder.unparsed("amount", String.valueOf(amount)),
                Placeholder.unparsed("item", Fmt.name(order.material)));
    }

    /** Isara ang lahat ng bukas na delivery chest (shutdown), para ma-process ang laman. */
    public void closeAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof DeliverHolder) {
                p.closeInventory();
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof DeliverHolder holder)) {
            return;
        }
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }
        process(player, holder);
    }

    private void process(Player player, DeliverHolder holder) {
        Inventory inv = holder.inventory;
        Order order = orders.find(holder.orderId);

        long cap = order == null ? 0 : Math.min(holder.maxAmount, order.remaining());
        ItemStack reference = order == null ? null : new ItemStack(order.material);

        long taken = 0;
        List<ItemStack> giveBack = new ArrayList<>();
        for (ItemStack item : inv.getContents()) {
            if (item == null || item.getType().isAir()) {
                continue;
            }
            if (order != null && taken < cap && item.isSimilar(reference)) {
                long can = Math.min(item.getAmount(), cap - taken);
                taken += can;
                if (can < item.getAmount()) {
                    ItemStack rest = item.clone();
                    rest.setAmount((int) (item.getAmount() - can));
                    giveBack.add(rest);
                }
            } else {
                giveBack.add(item);
            }
        }
        inv.clear();

        // Ibalik ang hindi tumugma / sobra.
        if (!giveBack.isEmpty()) {
            HashMap<Integer, ItemStack> leftovers = player.getInventory().addItem(giveBack.toArray(new ItemStack[0]));
            for (ItemStack left : leftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), left);
            }
        }

        if (order == null) {
            msg.send(player, "order-gone");
            return;
        }
        if (taken <= 0) {
            msg.send(player, "order-nothing");
            return;
        }

        order.delivered += taken;
        orders.save();

        double payout = taken * order.price;
        startDelivering(player, order, taken, payout);

        Player owner = Bukkit.getPlayer(order.owner);
        if (owner != null && owner.isOnline()) {
            msg.send(owner, "order-delivered-to-owner",
                    Placeholder.unparsed("player", player.getName()),
                    Placeholder.unparsed("amount", String.valueOf(taken)),
                    Placeholder.unparsed("item", Fmt.name(order.material)));
        }
    }

    /** "Delivering..." na may delay, tapos bayad. */
    private void startDelivering(Player player, Order order, long amount, double payout) {
        int seconds = Math.max(0, plugin.getConfig().getInt("orders.delivery-delay-seconds", 3));
        String item = Fmt.name(order.material);
        AtomicBoolean paid = new AtomicBoolean(false);

        Runnable pay = () -> {
            if (!paid.compareAndSet(false, true)) {
                return;
            }
            eco.deposit(player, payout);
            if (player.isOnline()) {
                msg.send(player, "order-paid",
                        Placeholder.unparsed("amount", String.valueOf(amount)),
                        Placeholder.unparsed("item", item),
                        Placeholder.unparsed("money", Fmt.money(payout)));
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
            }
        };
        orders.addPending(pay);

        if (seconds == 0) {
            orders.removePending(pay);
            pay.run();
            return;
        }

        new BukkitRunnable() {
            int left = seconds;

            @Override
            public void run() {
                if (paid.get()) {
                    cancel();
                    return;
                }
                if (left <= 0) {
                    cancel();
                    orders.removePending(pay);
                    pay.run();
                    return;
                }
                if (player.isOnline()) {
                    player.sendActionBar(msg.raw("order-delivering"));
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
                }
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
}
